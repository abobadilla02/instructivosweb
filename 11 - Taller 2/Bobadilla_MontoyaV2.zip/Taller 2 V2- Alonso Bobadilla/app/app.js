'use strict';
(function() {
	angular.
	module('app', ['ngStorage', 'directivas']);
})();