'use strict';
(function() {
	var app = angular.module('app', ['directives-example', 'app-controller']);
})();