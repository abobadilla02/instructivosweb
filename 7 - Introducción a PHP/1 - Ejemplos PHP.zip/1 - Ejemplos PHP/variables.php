<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Definición de variables</title>
</head>
<body>
	<?php
		$txt = "Hola mundo!! :D";
		$x = 3;
		$y = 20.8;

		echo $txt;
		echo "<br>";
		echo $x;
		echo "<br>";
		echo $y;
	?>
</body>
</html>