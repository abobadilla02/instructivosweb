<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>GET</title>
</head>
<body>
	<?php 
		echo "Nombre: " . $_GET['nombre'];
		echo "<br>"
		echo "Apellido: " . $_GET['apellido'];
 	?>
</body>
</html>