<?php 
	$server = "localhost";
	$usuario = "root";
	$pass = "dark199224";
	$database = "crudphp";

	$db = new mysqli($server, $usuario, $pass, $database);	
