$(document).ready(function() {
	$("#btn").hover(function() {
		$("button").toggleClass("btn-warning");
	});
});