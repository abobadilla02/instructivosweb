window.onload = function() {
	var elevator = new Elevator({
		element: document.querySelector('.elevator-button')
	});
}