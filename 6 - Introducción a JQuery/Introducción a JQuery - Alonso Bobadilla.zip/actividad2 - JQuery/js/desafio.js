$(document).ready(function() {
	$('.modal').modal();
});

$(document).ready(function(){
    $('ul.tabs').tabs();
});
